<h1 align="center">
  The Ark Innovations Project in React Gatsby
</h1>
